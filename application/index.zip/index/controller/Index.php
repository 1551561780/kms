<?php
/**
 *       ～～         ～～        　～～
 *    ~~　　　　　~~　　　　　　~~
 * ~~～~~～~~　　~~~～~~～~~～　　~~~～~~～~~～ 
 * ·········   ·········Bury·······  ················
 * ·················································· 
 * @Author: wz <1551561780@qq.com>
 * @Date:   
 * @Explanation: Index 首页 框架  
 */ 

namespace app\index\controller;
use think\Db;
use think\Controller; 
use think\Request;   
use think\Hook;  
use think\Lang;

class Index extends Controller
{
 
    #加载首页框架
 	#
    public function index(){ 
    	//$param = vensTrim(input('param.')); 	
      
        return $this->fetch(); 
    }


    public function upload(){
    	 //实例化并获取系统变量传参

    	 
			$upload = new   \com\Upload($_FILES['file']['tmp_name'],$_POST['blob_num'],$_POST['total_blob_num'],$_POST['file_name']);
			//调用方法，返回结果
			$upload->apiReturn(); 

    }
 
}

 

 
